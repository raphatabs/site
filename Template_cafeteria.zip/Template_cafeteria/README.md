# site
Bem-vindo ao repositório do nosso projeto de treinamento! Este site foi criado com o propósito exclusivo de servir como uma plataforma de teste para estudantes que estão aprendendo a trabalhar com HTML. 

Aqui, você encontrará uma variedade de exemplos e exercícios projetados para ajudá-lo a entender melhor a estrutura e o funcionamento do HTML em um ambiente prático. Lembre-se, este site é destinado apenas para fins educacionais e testes, então sinta-se livre para explorar, modificar e experimentar conforme você avança em sua jornada de aprendizado. Boa sorte!

<a href="https://josetelmo.github.io/site"  target="_blank" rel="noopener noreferrer">Confira o site!</a>

